// Fetch and display news
fetch("news.json")
  .then((res) => res.json())
  .then((data) => {
    // =======================
    // Main Headline (first news)
    // =======================
    const main = document.getElementById("main-news");
    if (main && data.length > 0) {
      const mainNews = data[0];
      main.innerHTML = `
        <div class="main-news">
          <img src="${mainNews.image}" alt="${mainNews.title}" />
          <h1>${mainNews.title}</h1>
          <p>${mainNews.summary}</p>
          <small>${mainNews.date}</small>
          <a href="news.html?slug=${mainNews.slug}" class="read-more">Read More</a>
        </div>
      `;
    }

    // =======================
    // Other News (small cards)
    // =======================
    const grid = document.getElementById("news-grid");
    if (grid) {
      for (let i = 1; i < data.length; i++) {
        const news = data[i];
        grid.innerHTML += `
          <div class="news-card small">
            <img src="${news.image}" alt="news image" />
            <div class="news-content">
              <h2>${news.title}</h2>
              <p>${news.summary}</p>
              <small>${news.date}</small>
              <a href="news.html?slug=${news.slug}" class="read-more">Read more</a>
            </div>
          </div>
        `;
      }
    }

    // =======================
    // Single News Page (news.html)
    // =======================
    const params = new URLSearchParams(window.location.search);
    const slug = params.get("slug");
    if (slug) {
      const news = data.find((item) => item.slug === slug);
      const detail = document.getElementById("news-detail");
      if (detail && news) {
        detail.innerHTML = `
          <h1>${news.title}</h1>
          <img src="${news.image}" alt="${news.title}" />
          <small>${news.date}</small>
          <p>${news.content}</p>
        `;
      }
    }
  })
  .catch((err) => console.error("Error loading news:", err));


function loadNewsByCategory(categoryName) {
  fetch("news.json")
    .then(response => response.json())
    .then(data => {
      const container = document.getElementById("news-container");
      container.innerHTML = "";

      const filteredNews = data.filter(news => news.category === categoryName);

      filteredNews.forEach(news => {
        const newsCard = document.createElement("div");
        newsCard.classList.add("news-card");

        newsCard.innerHTML = `
          <a href="single.html?slug=${news.slug}">
            <img src="${news.image}" alt="${news.title}">
            <h2>${news.title}</h2>
            <p>${news.summary}</p>
            <span class="news-date">${news.date}</span>
          </a>
        `;

        container.appendChild(newsCard);
      });
    })
    .catch(error => console.error("Error loading category news:", error));
}

